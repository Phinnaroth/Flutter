import 'package:myproject/final_exam/models/course.dart';
import 'package:myproject/final_exam/models/student_score.dart';

final course = [
  Course(name: 'HTML'),
  Course(name: 'Java'),
  StudentScore(stuName: 'Naroth', score: 67),
  StudentScore(stuName: 'Bona', score: 56),

];