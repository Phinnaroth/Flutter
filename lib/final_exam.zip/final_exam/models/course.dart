class Course{
  final String name;

  var _stuScore;

  Course({required this.name});
}