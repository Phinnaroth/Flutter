class StudentScore {
  final String stuName;
  final double score;

StudentScore({required this.stuName, required this.score});
}